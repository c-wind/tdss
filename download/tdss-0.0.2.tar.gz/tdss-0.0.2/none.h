/* none.h.  Generated from none.h.in by configure.  */
