#ifndef __NAME_SERVER_H__
#define __NAME_SERVER_H__


int ns_file_info_add(inet_task_t *it);

int ns_file_info_set(inet_task_t *it);

#endif

